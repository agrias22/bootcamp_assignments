import React, { Component, useState }  from 'react';

const TabButton = ({inf, idx, setIndex}) =>{
    const [clickTab, setClickTab] = useState("");
    const onClickHandler = () => {
        setIndex(idx);
    }
    return(  
        <div style={{display:'inline-block'}}>
            <button onClick= {onClickHandler}>Tab</button>
        </div>
    );
}

export default TabButton