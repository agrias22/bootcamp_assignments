import './App.css';
import { useState } from 'react';
import MakeList from "./components/make.jsx"
import CreateItem from "./components/create.jsx"
function App() {
  const [toDo, setTodo] = useState([
    {item: "Get Mern Black Belt", status: true},
    {item: "Go To Cancun", status: false},
    {item: "Slack Off", status:false}
  ]);

  const newItem = (item) => {
    setTodo([...toDo,item]);
  };

  const deleteItem = (deleteIdx, Status) =>{  
    if(Status == true){
      setTodo(toDo.filter((item, idx) => idx !== deleteIdx ? true : false));
    }
  }

  const updateItem = (idx) =>{
    const copyItem = [...toDo];
    copyItem[idx].status = !copyItem[idx].status
    setTodo(copyItem);
  }
  return (
    <div>  
      <h1>To Do List!</h1>
      <CreateItem newItem ={newItem}/>
      <MakeList toDo ={toDo} deleteItem={deleteItem} updateItem={updateItem}/>
    </div>
  );
}

export default App;
