import React, { Component, useState }  from 'react';

const UserForm = props => {
    const [firstName, setfirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");

    const createUser = (e) => {
        e.preventDefault();
        const newUser = {firstName, lastName, email, password};
    };

    return(
        <div>
            <form onSubmit={createUser}>
                <div class="formInput">
                    <label>First Name: </label>
                    <input type="text" onChange={ (e) => setfirstName(e.target.value)}/>
                </div>
                <div class="formInput">
                    <label>Last Name: </label>
                    <input type="text" onChange={ (e) => setLastName(e.target.value)}/>
                </div>
                <div class="formInput">
                    <label>Email: </label>
                    <input type="text" onChange={ (e) => setEmail(e.target.value)}/>
                </div>
                <div class="formInput">
                    <label>Password: </label>
                    <input type="text" onChange={ (e) => setPassword(e.target.value)}/>
                </div>
                <div class="formInput">
                    <label>Confirm Password: </label>
                    <input type="text" onChange={ (e) => setConfirmPassword(e.target.value)}/>
                </div>
                <button type="submit">Your Form Data</button>
            </form>
            <p>
                First Name: {firstName}
            </p>
            <p>
                Last Name: {lastName}
            </p>
            <p>
                Email: {email}
            </p>
            <p>
                Password: {password}
            </p>
            <p>
                Confirm Password: {confirmPassword}
            </p>
        </div>
    );
}
export default UserForm