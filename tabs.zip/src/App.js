import { useState } from 'react';
import './App.css';
import TabButton from './components/tabbutton.jsx'
import Buttons from './components/buttons.jsx'

function App() {
  const[index, setIndex] = useState(2)
  const [info, setInfo] = useState([
    {text: 'information'},
    {text: 'more information'},
    {text: 'even more information'},
  ]);
  

  return (
    <div className="App">
      <h1>Hello World!</h1>
      <Buttons info={info} setIndex={setIndex}/>
      <p>{info[index].text}</p>
    </div>
  );
}

export default App;
