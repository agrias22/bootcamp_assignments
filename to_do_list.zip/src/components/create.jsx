import React, { useState }  from 'react';

const CreateItem = ({newItem}) =>{
    const[item, setItem] = useState("");
    
    const Creation = (event) =>{
        event.preventDefault();
        newItem({item: item});
    }
    return(
        <div>
            <form onSubmit={Creation}>
                <input type="text"  onChange={ (e) => setItem(e.target.value)}></input>
                <button type="submit">Add</button>
            </form>
            <inpt type='checkbox'></inpt>
        </div>
    )
}

export default CreateItem