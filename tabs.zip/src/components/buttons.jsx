import React, { Component, useState }  from 'react';
import TabButton from "./tabbutton"

const Buttons = ({info, setIndex}) =>{
    return (
        info.map((inf, idx) =>
        <TabButton key={idx} inf={inf} idx={idx} setIndex={setIndex}/>
        )
    )
}
export default Buttons