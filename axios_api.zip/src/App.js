import './App.css';
import React, { useState }  from 'react';
import axios from 'axios';

function App() {
  const [pokemon, setPokemon] = useState([]);  
  const onClickHandler = (e) => {
    axios.get('https://pokeapi.co/api/v2/pokemon?limit=807&offset=0').then(response=>{
      setPokemon(response.data.results);
  })}

  return (
    <div className="App">
      <h1>Pokemon API</h1>
      <button onClick= {onClickHandler}>Fetch Pokemon</button>
      {pokemon.length > 0 && pokemon.map((monster, index)=>{
                return (<ul key={index}><li>{monster.name}</li></ul>)
          })}
    </div>
  );
}

export default App;
