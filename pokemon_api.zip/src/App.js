import './App.css';
import React, { useEffect, useState }  from 'react';

function App() {
  const [pokemon, setPokemon] = useState([]);
    
  const onClickHandler = (e) => {
    fetch('https://pokeapi.co/api/v2/pokemon?limit=807&offset=0')
    .then(response => response.json())
    .then(response => setPokemon(response.results))
  }
  console.log(pokemon)

  return (
    <div className="App">
      <h1>Pokemon API</h1>
      <button onClick= {onClickHandler}>Fetch Pokemon</button>
      {pokemon.length > 0 && pokemon.map((monster, index)=>{
                return (<ul key={index}><li>{monster.name}</li></ul>)
          })}
    </div>
  );
}

export default App;
