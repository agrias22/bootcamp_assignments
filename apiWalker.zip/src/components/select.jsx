import React from 'react';
import { useState } from 'react';

const  Select = ({finalSelect, selectDrop}) => {
    const [result, setResult] = useState('');
    console.log(selectDrop);
    if(finalSelect > 0){    
        setResult(Object.keys(finalSelect))
        console.log(result)
    }
    if (selectDrop === 'people'){
        return(
            <div>
                <h2>{finalSelect.name}</h2>
                <h2>Height: {finalSelect.height}</h2>
                <h2>Mass: {finalSelect.mass} kg</h2>
                <h2>Hair Color: {finalSelect.hair_color}</h2>
                <h2>Gender: {finalSelect.gender}</h2>
            </div>
        )
    }
    else if (selectDrop === 'planets'){
        return(
            <div>
                <h2>{finalSelect.name}</h2>
                <h2>Climate: {finalSelect.climate}</h2>
                <h2>Diameter: {finalSelect.diameter}</h2>
                <h2>Terrian: {finalSelect.terrain}</h2>
                <h2>Population: {finalSelect.population}</h2>
            </div>
        )
    }
    else if(selectDrop === 'films'){
        return(
            <div>
                <h2>{finalSelect.name}</h2>
                <h2>Director: {finalSelect.director}</h2>
                <h2>Opening Crawl: {finalSelect.opening_crawl}</h2>
                <h2>Producer: {finalSelect.producer}</h2>
                <h2>Release Date: {finalSelect.release_date}</h2>
            </div>
        )
    }
    else if(selectDrop === 'species'){
        return(
            <div>
                <h2>{finalSelect.name}</h2>
                <h2>Average Height: {finalSelect.average_height} M</h2>
                <h2>Average LifeSpan: {finalSelect.average_lifespan} Years</h2>
                <h2>Language: {finalSelect.language}</h2>
                <h2>Classification: {finalSelect.classification}</h2>
            </div>
        )
    }
    else if(selectDrop === 'vehicles'){
        return(
            <div>
                <h2>{finalSelect.name}</h2>
                <h2>Cargo Capicity: {finalSelect.cargo_capacity} M</h2>
                <h2>Cost in Credits: {finalSelect.cost_in_credits} Years</h2>
                <h2>Length: {finalSelect.length} M</h2>
                <h2>Model: {finalSelect.model}</h2>
            </div>
        )
    }
    else if(selectDrop === 'starships'){
        return(
            <div>
            <h2>{finalSelect.name}</h2>
            <h2>Model: {finalSelect.model} M</h2>
            <h2>Cost in Credits: {finalSelect.cost_in_credits} Years</h2>
            <h2>Length: {finalSelect.length} M</h2>
            <h2>Length: {finalSelect.length}</h2>
        </div>
        )
    }
    else{
        return(
        <div>
            <div>
            <h1>These are not the droids you are looking for</h1>
            </div>
        </div>
        )
    }
}

export default Select