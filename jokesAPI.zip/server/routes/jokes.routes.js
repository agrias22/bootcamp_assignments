const JokesController = require('../controllers/jokes.controller')

module.exports = app =>{
    app.get('/api/jokes/', JokesController.findAllJokes);
    app.get('/api/jokes/:id', JokesController.findOneJoke);
    app.post('/api/jokes/new', JokesController.createNewJoke);
    app.put('/api/jokes/update/:id', JokesController.updateExistingJoke);
    app.delete('/api/delete/:id', JokesController.deleteAnExistingUser);
    app.get('/api/jokes/hello', JokesController.hello)
};