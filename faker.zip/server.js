const faker = require('faker');
const express = require('express');

const app = express();

class User{
    constructor(){
        this.id = faker.random.number();
        this.firstName = faker.name.firstName();
        this.lastName = faker.name.lastName();
        this.phoneNumber = faker.phone.phoneNumber();
        this.email = faker.internet.email();
        this.password = faker.internet.password();
    }
}
class Company{
    constructor(){
        this.id = faker.random.number();
        this.address = faker.address.streetAddress();
        this.city = faker.address.city();
        this.state = faker.address.state();
        this.zipcode = faker.address.zipCode();
        this.country = faker.address.country();
    }
}
function createTwo(){
    const Jeff = new User();
    const Toy = new Company();
    const newArr = [];
    newArr.push(Jeff);
    newArr.push(Toy);
    return(newArr);
}
app.use(express.json());

app.get('/', (request, response) =>{
    console.log(request);
    response.send("Hello World! This is a the server!")
})
app.get('/api/users/new', (request, response) =>{
    response.json(new User());
})

app.get('/api/company/new', (request, response) =>{
    response.json(new Company());
})

app.get('/api/user/company', (request, response) =>{
    response.json(createTwo());
})

app.get('/user/:id', (request,response) =>{
    console.log(request.params);
    response.send("This is how we send the params to the webpage")

})
app.listen(8000, () => {
    console.log('Running on Port 8000!');
})