import './App.css';
import axios from 'axios';
import { useEffect, useState } from 'react';
import Select from './components/select.jsx';
import { navigate, Router } from '@reach/router'

function App() {
  const [responseData, setResponseData] = useState([]);
  const[selectDrop, setSelectDrop] = useState([]);
  const[userSelect, setUserSelect] = useState([]);
  const[userID, setUserID] = useState('');
  const[finalSelect, setFinalSelect] = useState('');
  const[error, setError] = useState('');
  
  useEffect(()=>{
    axios.get('https://swapi.dev/api/')
        .then(response=>{setResponseData(response.data)})
    }, []);
  
  const apiKeys = Object.keys(responseData)
    
  const handleSubmit = (e) => {
    e.preventDefault();
    axios.get('https://swapi.dev/api/' + String(selectDrop))
    .then(userSelect=>{setUserSelect(userSelect.data.results)})
    navigate('/' + String(selectDrop))
    if(userID){
      axios.get('https://swapi.dev/api/' + String(selectDrop) + '/' + String(userID))
      .then(finalSelect=>{setFinalSelect(finalSelect.data)})
      navigate('/' + String(selectDrop) + '/' + String(userID))
    }
  }
  
  if(!userSelect){
    setError('These arent the droids you are looking for')
  }

  console.log(userSelect)
  return (
    <div className="App">
      <h1>Luke API Walker</h1>
      <form onSubmit={handleSubmit}>
        <select value= {selectDrop} onChange={e => setSelectDrop(e.target.value)}>
          {apiKeys.map((item, idx) => (
          <option key={idx} value={item}>{item}</option>
        ))}
        </select>
        <select value= {userID} onChange={e => setUserID(e.target.value)}>
          {userSelect.map((item, idx) => (
          <option key={idx} value={idx} >{idx}</option>
        ))}
        </select>
        <button type='submit'>Submit</button>
      </form>
            
        <Select finalSelect ={finalSelect} selectDrop = {selectDrop}/>
        <p>{error}</p>
    </div>
  );
}

export default App;
