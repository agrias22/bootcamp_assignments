import React, { useState }  from 'react';
import ListItem from "./list"
const MakeList = ({toDo, deleteItem, updateItem}) =>{
    return(
        toDo.map((item, idx) => 
        <ListItem key={idx} item={item} idx={idx} deleteItem={deleteItem} updateItem={updateItem}/>
        )
    )
}
export default MakeList