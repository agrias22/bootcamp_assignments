import React, { useState }  from 'react';

const ListItem = ({item, idx, deleteItem, updateItem}) =>{
    const checked = "line-through";
    const unchecked = "";
    return(
        <div>
            <p style={{ textDecoration: item.status ? checked : unchecked}}>{item.item}</p>
            <input type="checkbox" checked={item.status} onClick={e => updateItem(idx)}></input>
            <button type onClick={(e) => deleteItem(idx, item.status)}>Delete</button>
        </div>
    );
}
export default ListItem