import React, { Component }  from 'react';

class PersonCard extends Component{
    constructor(props) {
        super(props);
        this.state = {
            age: this.props.age
        }
    }

    countHandler = () => {
        this.setState({
            age: this.state.age + 1
        })
    }
    render(){
        return <div>
            <h1>{ this.props.lastName }, {this.props.firstname}</h1>
            <p>Age: {this.props.age}</p>
            <p>Hair Color: {this.props.hair}</p>
            <p>The Button has been click {this.state.age} </p>
            <button onClick={this.countHandler}> Birthday Button for {this.props.firstname} {this.props.lastName}</button>
        </div> ;
    }
}

export default PersonCard